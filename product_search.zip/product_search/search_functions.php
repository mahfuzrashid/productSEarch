<?php
//call this function to core file
//require_once MRTECHPLUGIN_PLUGIN_PATH . '/product_search/search_functions.php';

//enque Script

function mrtech_search_scripts() {
		wp_enqueue_script( 'search_core', plugins_url( 'search_core.js', __FILE__ ), array( 'jquery' ), '1.0', true );
		wp_enqueue_style( 'search', plugins_url( 'search.css', __FILE__ ));

		}

add_action( 'wp_enqueue_scripts', 'mrtech_search_scripts' );

// Register Custom Taxonomy
	function make_year_func() {
		$labels = array(
			'name'              => _x( 'Years', 'brator-core' ),
			'singular_name'     => _x( 'Year', 'brator-core' ),
			'search_items'      => __( 'Search Year' ),
			'all_items'         => __( 'All Year' ),
			'parent_item'       => __( 'Parent Year' ),
			'parent_item_colon' => __( 'Parent Year:' ),
			'edit_item'         => __( 'Edit Year' ),
			'update_item'       => __( 'Update Year' ),
			'add_new_item'      => __( 'Add New Year' ),
			'new_item_name'     => __( 'New Year' ),
			'menu_name'         => __( 'Years' ),
		);
		$args   = array(
			'hierarchical'          => false,
			'public'                => true,
			'labels'                => $labels,
			'show_ui'               => true,
			'show_admin_column'     => false,
			'update_count_callback' => '_update_post_term_count',
			'query_var'             => true,
			'rewrite'               => array( 'slug' => 'product-year' ),
		);
		register_taxonomy( 'make_year', array( 'product' ), $args );
	}
	
add_action( 'init', 'make_year_func', 0 );	


 function make_brand_func() {
		$labels = array(
			'name'              => _x( 'Brands', 'brator-core' ),
			'singular_name'     => _x( 'Brand', 'brator-core' ),
			'search_items'      => __( 'Search Brand', 'brator-core' ),
			'all_items'         => __( 'All Brand', 'brator-core' ),
			'parent_item'       => __( 'Parent Brand', 'brator-core' ),
			'parent_item_colon' => __( 'Parent Brand:', 'brator-core' ),
			'edit_item'         => __( 'Edit Brand', 'brator-core' ),
			'update_item'       => __( 'Update Brand', 'brator-core' ),
			'add_new_item'      => __( 'Add New Brand', 'brator-core' ),
			'new_item_name'     => __( 'New Brand', 'brator-core' ),
			'menu_name'         => __( 'Brands', 'brator-core' ),
		);
		$args   = array(
			'hierarchical'      => false,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => false,
			'query_var'         => true,
			'rewrite'           => array( 'slug' => 'product-brand' ),
		);

		register_taxonomy( 'make_brand', array( 'product' ), $args );
	}
add_action( 'init', 'make_brand_func', 0 );	


	function make_model_func() {
		$labels = array(
			'name'              => _x( 'Models', 'brator-core' ),
			'singular_name'     => _x( 'Model', 'brator-core' ),
			'search_items'      => __( 'Search Model', 'brator-core' ),
			'all_items'         => __( 'All Model', 'brator-core' ),
			'parent_item'       => __( 'Parent Model', 'brator-core' ),
			'parent_item_colon' => __( 'Parent Model:', 'brator-core' ),
			'edit_item'         => __( 'Edit Model', 'brator-core' ),
			'update_item'       => __( 'Update Model', 'brator-core' ),
			'add_new_item'      => __( 'Add New Model', 'brator-core' ),
			'new_item_name'     => __( 'New Model', 'brator-core' ),
			'menu_name'         => __( 'Models', 'brator-core' ),
		);
		$args   = array(
			'hierarchical'      => false,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => false,
			'query_var'         => true,
			'rewrite'           => array( 'slug' => 'product-model' ),
		);

		register_taxonomy( 'make_model', array( 'product' ), $args );
	}
add_action( 'init', 'make_model_func', 0 );	

	function make_engine_func() {
		$labels = array(
			'name'              => _x( 'Engines', 'brator-core' ),
			'singular_name'     => _x( 'Engine', 'brator-core' ),
			'search_items'      => __( 'Search Engine' ),
			'all_items'         => __( 'All Engine' ),
			'parent_item'       => __( 'Parent Engine' ),
			'parent_item_colon' => __( 'Parent Engine:' ),
			'edit_item'         => __( 'Edit Engine' ),
			'update_item'       => __( 'Update Engine' ),
			'add_new_item'      => __( 'Add New Engine' ),
			'new_item_name'     => __( 'New Engine' ),
			'menu_name'         => __( 'Engines' ),
		);
		$args   = array(
			'hierarchical'      => false,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => false,
			'query_var'         => true,
			'rewrite'           => array( 'slug' => 'product-engine' ),
		);

		register_taxonomy( 'make_engine', array( 'product' ), $args );
	}
add_action( 'init', 'make_engine_func', 0 );	


//ShortCode for Banner and reset [brator_search_result_banner]

add_action( 'brator_search_result_banner', 'brator_search_result_banner_func' );
function brator_search_result_banner_func() {
	$makeyear   = '';
	$makebrand  = '';
	$makemodel  = '';
	$makeengine = '';

	if ( isset( $_GET['makeyear'] ) && ! empty( $_GET['makeyear'] ) ) {
		$makeyear = $_GET['makeyear'];
		$makeyear = str_replace( '-', ' ', $makeyear );
	}

	if ( isset( $_GET['brand'] ) && ! empty( $_GET['brand'] ) ) {
		$makebrand = $_GET['brand'];
		$makebrand = str_replace( '-', ' ', $makebrand );
	}

	if ( isset( $_GET['model'] ) && ! empty( $_GET['model'] ) ) {
		$makemodel = $_GET['model'];
		$makemodel = str_replace( '-', ' ', $makemodel );
	}

	if ( isset( $_GET['engine'] ) && ! empty( $_GET['engine'] ) ) {
		$makeengine = $_GET['engine'];
		$makeengine = str_replace( '-', ' ', $makeengine );
	}

	$shop_page_url = get_permalink( wc_get_page_id( 'shop' ) );
	if ( isset( $_REQUEST['search'] ) == 'advanced' && ! is_admin() ) {
		?>
	<div class="brator-current-vehicle-area">
		<div class="container-xxxl container-xxl container">
			<div class="row">
				<div class="col-12">
					<div class="brator-current-vehicle">
						<div class="brator-current-vehicle-content">
							<p><?php esc_html_e( 'Your current vehicle', 'brator-core' ); ?></p>
							<h4><?php esc_html_e( 'Auto Parts for', 'brator-core' ); ?> <span> <?php echo esc_html( $makeyear . ' ' . $makebrand . ' ' . $makemodel . ' ' . $makeengine ); ?> </span></h4>
						</div>
						<div class="brator-current-vehicle-content"><a href="<?php echo esc_url( $shop_page_url ); ?>"><?php esc_html_e( 'Reset', 'brator-core' ); ?></a></div>
					</div>
				</div>
			</div>
		</div>
	</div>
		<?php
	}
}	



//Query Short-codes [brator_auto_parts_vehicle_ready]


add_shortcode( 'brator_auto_parts_vehicle_ready', 'brator_auto_parts_vehicle_ready_func' );
function brator_auto_parts_vehicle_ready_func() {
	?>
	<form method="post" id="advanced-searchform" class="brator-parts-search-box-form">
		<select class="select-year-parts brator-select-active" id="makeyear" name="makeyear">
			<option value=""><?php esc_html_e( 'Year', 'brator-core' ); ?></option>
			<?php
			$make_year = get_terms(
				array(
					'taxonomy'   => 'make_year',
					'hide_empty' => false,
				)
			);
			if ( ! empty( $make_year ) ) {
				foreach ( $make_year as $single ) {
					echo '<option value="' . $single->slug . '">' . $single->name . '</option>';
				}
			}
			?>
		</select>
		<select class="select-make-parts brator-select-active" id="makebrand" name="brand" disabled>
			<option value=""><?php esc_html_e( 'Make', 'brator-core' ); ?></option>
			<?php
				$make_brand = get_terms(
					array(
						'taxonomy'   => 'make_brand',
						'hide_empty' => false,
					)
				);
			if ( ! empty( $make_brand ) ) {
				foreach ( $make_brand as $single ) {
					echo '<option value="' . $single->slug . '">' . $single->name . '</option>';
				}
			}
			?>
		</select>
		<select class="select-model-parts brator-select-active" id="makemodel" name="model" disabled>
			<option value=""><?php esc_html_e( 'Model', 'brator-core' ); ?></option>
			<?php
			$make_model = get_terms(
				array(
					'taxonomy'   => 'make_model',
					'hide_empty' => false,
				)
			);
			if ( ! empty( $make_model ) ) {
				foreach ( $make_model as $single ) {
					echo '<option value="' . $single->slug . '">' . $single->name . '</option>';
				}
			}
			?>
		</select>
		<select class="select-engine-parts brator-select-active" id="makeengine" name="engine" disabled>
			<option value=""><?php esc_html_e( 'Engine', 'brator-core' ); ?></option>
			<?php
			$make_engine = get_terms(
				array(
					'taxonomy'   => 'make_engine',
					'hide_empty' => false,
				)
			);
			if ( ! empty( $make_engine ) ) {
				foreach ( $make_engine as $single ) {
					echo '<option value="' . $single->slug . '">' . $single->name . '</option>';
				}
			}
			?>
		</select>
		<button name="adv_brator_form" type="submit"><?php esc_html_e( 'Add Vehicle', 'brator-core' ); ?></button>
	  </form>
	<?php
	if ( isset( $_POST['adv_brator_form'] ) ) {
		// $_SESSION['makeyear'] = $_POST['makeyear'];
		// $_SESSION['brand']    = $_POST['brand'];
		// $_SESSION['model']    = $_POST['model'];
		// $_SESSION['engine']   = $_POST['engine'];

		$_SESSION['vehicle_items'][] = array(
			'makeyear' => $_POST['makeyear'],
			'brand'    => $_POST['brand'],
			'model'    => $_POST['model'],
			'engine'   => $_POST['engine'],
		);
	}

	// print_r( $_SESSION['vehicle_items'] );
	if ( ! empty( $_SESSION['vehicle_items'] ) ) {
		?>
		<ul class="vehicle-list">
		<?php foreach ( $_SESSION['vehicle_items'] as $val ) { ?>
			<li><?php echo $val['makeyear'] . ' ' . $val['brand'] . ' ' . $val['model'] . '<span>' . $val['engine'] . '</span>'; ?></li>
		<?php } ?>
			<li id="clearvehicle"><?php esc_html_e( 'Clear History', 'brator-core' ); ?></li>
		</ul>
		<?php
	}
}

//Query Short-codes [brator_auto_parts_search]
add_shortcode( 'brator_auto_parts_search', 'brator_auto_parts_search_func' );
function brator_auto_parts_search_func() {
	$shop_page_url = get_permalink( wc_get_page_id( 'shop' ) );
	?>
	<form method="get" id="advanced-searchform" class="brator-parts-search-box-form" role="search" action="<?php echo $shop_page_url; ?>">
		  <input type="hidden" name="search" value="advanced">
		<select class="select-year-parts brator-select-active" id="makeyear" name="makeyear">
			<option value=""><?php esc_html_e( 'Year', 'brator-core' ); ?></option>
			<?php
			$make_year = get_terms(
				array(
					'taxonomy'   => 'make_year',
					'hide_empty' => false,
				)
			);
			if ( ! empty( $make_year ) ) {
				foreach ( $make_year as $single ) {
					echo '<option value="' . $single->slug . '">' . $single->name . '</option>';
				}
			}
			?>
		</select>
		<select class="select-make-parts brator-select-active" id="makebrand" name="brand" disabled>
			  <option value=""><?php esc_html_e( 'Make', 'brator-core' ); ?></option>
			<?php
			$make_brand = get_terms(
				array(
					'taxonomy'   => 'make_brand',
					'hide_empty' => false,
				)
			);
			if ( ! empty( $make_brand ) ) {
				foreach ( $make_brand as $single ) {
					echo '<option value="' . $single->slug . '">' . $single->name . '</option>';
				}
			}
			?>
		</select>
		<select class="select-model-parts brator-select-active" id="makemodel" name="model" disabled>
			<option value=""><?php esc_html_e( 'Model', 'brator-core' ); ?></option>
			<?php
			$make_model = get_terms(
				array(
					'taxonomy'   => 'make_model',
					'hide_empty' => false,
				)
			);
			if ( ! empty( $make_model ) ) {
				foreach ( $make_model as $single ) {
					echo '<option value="' . $single->slug . '">' . $single->name . '</option>';
				}
			}
			?>
		</select>
		<select class="select-engine-parts brator-select-active" id="makeengine" name="engine" disabled>
			<option value=""><?php esc_html_e( 'Engine', 'brator-core' ); ?></option>
			<?php
			$make_engine = get_terms(
				array(
					'taxonomy'   => 'make_engine',
					'hide_empty' => false,
				)
			);
			if ( ! empty( $make_engine ) ) {
				foreach ( $make_engine as $single ) {
					echo '<option value="' . $single->slug . '">' . $single->name . '</option>';
				}
			}
			?>
		</select>
		<button type="submit"><?php esc_html_e( 'Search', 'brator-core' ); ?></button>
	  </form>
		<?php
}


add_filter( 'woocommerce_product_query', 'brator_advanced_search_query' );
function brator_advanced_search_query( $query ) {

	$makeyear   = '';
	$makebrand  = '';
	$makemodel  = '';
	$makeengine = '';

	// if ( isset( $_REQUEST['search'] ) && $_REQUEST['search'] == 'advanced' && ! is_admin() && $query->is_search && $query->is_main_query() ) {
	if ( isset( $_REQUEST['search'] ) == 'advanced' && ! is_admin() ) {
		if ( $query->query_vars['post_type'] == 'product' ) {
			$query->set( 'post_type', 'product' );

			if ( isset( $_GET['makeyear'] ) && ! empty( $_GET['makeyear'] ) ) {
				$makeyear = array(
					'taxonomy' => 'make_year',
					'terms'    => $_GET['makeyear'],
					'field'    => 'slug',
				);
			}

			if ( isset( $_GET['brand'] ) && ! empty( $_GET['brand'] ) ) {
				$makebrand = array(
					'taxonomy' => 'make_brand',
					'terms'    => $_GET['brand'],
					'field'    => 'slug',
				);
			}

			if ( isset( $_GET['model'] ) && ! empty( $_GET['model'] ) ) {
				$makemodel = array(
					'taxonomy' => 'make_model',
					'terms'    => $_GET['model'],
					'field'    => 'slug',
				);
			}

			if ( isset( $_GET['engine'] ) && ! empty( $_GET['engine'] ) ) {
				$makeengine = array(
					'taxonomy' => 'make_engine',
					'terms'    => $_GET['engine'],
					'field'    => 'slug',
				);
			}

			if ( ! empty( $makeyear ) && ! empty( $makebrand ) && ! empty( $makemodel ) && ! empty( $makeengine ) ) {

				$tax_query = array(
					'relation' => 'AND',
					$makeyear,
					$makebrand,
					$makemodel,
					$makeengine,
				);
			} elseif ( ! empty( $makeyear ) && ! empty( $makebrand ) && ! empty( $makemodel ) ) {
				$tax_query = array(
					'relation' => 'AND',
					$makeyear,
					$makebrand,
					$makemodel,
				);
			} elseif ( ! empty( $makeyear ) && ! empty( $makebrand ) ) {
				$tax_query = array(
					'relation' => 'AND',
					$makeyear,
					$makebrand,
				);
			} else {
				$tax_query = array(
					'relation' => 'AND',
					$makeyear,
				);
			}
			$query->set( 'tax_query', $tax_query );
		}
	}
	remove_filter( 'woocommerce_product_query', 'brator_advanced_search_query' );

}



	
